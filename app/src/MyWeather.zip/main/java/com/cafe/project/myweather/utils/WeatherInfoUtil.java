package com.cafe.project.myweather.utils;

import java.util.Arrays;
import java.util.List;

/**
 * Created by cafe on 2017/5/14.
 */

public class WeatherInfoUtil {

    public static final List<String> airQuality = Arrays.asList("优", "良", "轻度污染", "中度污染", "重度污染", "严重污染");

}

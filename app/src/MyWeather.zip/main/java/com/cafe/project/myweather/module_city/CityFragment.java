package com.cafe.project.myweather.module_city;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.cafe.demo.library.adapter.SimpleRecyclerAdapter;
import com.cafe.demo.library.adapter.ViewHolder;
import com.cafe.demo.library.refresh.IRecyclerView;
import com.cafe.project.myweather.R;
import com.cafe.project.myweather.base.BaseListFragment;
import com.cafe.project.myweather.utils.LocationUtil;

import java.util.ArrayList;

/**
 * Created by cafe on 2017/5/10.
 */

public class CityFragment extends BaseListFragment {

    private ArrayList<String> cityList = new ArrayList<>();

    @Override
    public boolean hasTopView() {
        return false;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_city;
    }

    @Override
    public IRecyclerView getRefreshView(View view) {
        return (IRecyclerView) view.findViewById(R.id.id_city_list);
    }

    @Override
    public void downloadData() {
        String locationCity = LocationUtil.getLocationCityName();
        new Thread(new Runnable() {
            @Override
            public void run() {
                cityList.add("西安");
                cityList.add("运城");
                cityList.add("纽约");
                cityList.add("太原");
                cityList.add("天津");
                cityList.add("北京");
                cityList.add("长沙");
                cityList.add("广州");
                cityList.add("深圳");
                cityList.add("海南");

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        irecyclerView.completeRefresh();

                    }
                }, 1000);

            }
        }).start();
    }

    @Override
    public RecyclerView.Adapter getAdapter() {
        return new SimpleRecyclerAdapter<String>(mContext, R.layout.item_recycler_city_fragment, cityList) {
            @Override
            protected void getView(ViewHolder holder, String cityName, int position) {
                holder.setText(R.id.id_city_name, cityName);
            }
        };
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(mContext);
    }

    @Override
    public void initView(View view) {
        super.initView(view);


    }
}

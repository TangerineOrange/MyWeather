package com.cafe.project.myweather.base;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.LayoutRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cafe.project.myweather.MainActivity;
import com.cafe.project.myweather.R;

/**
 * Created by cafe on 2017/5/1.
 */

public abstract class BaseFragment extends Fragment {

    protected MainActivity mContext;

    protected static Handler handler = new Handler();
    protected View rootView;

    /**
     * 是否使用BaseFragment提供的统一的actionBar
     *
     * @return
     */
    public abstract boolean hasTopView();

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext = (MainActivity) context;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.i("onCreateView", "onCreateView");
        if (!hasTopView()) {
            return inflater.inflate(getLayoutId(), container, false);

        } else {
            View inflate = inflater.inflate(R.layout.fragment_base, container, false);

            inflater.inflate(getLayoutId(), (ViewGroup) inflate);
            return inflate;

        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.i("onViewCreated", "onViewCreated");
        this.rootView = view;

        //TODO
//        view.setFitsSystemWindows(true);

        initView(view);
    }

    @LayoutRes
    public abstract int getLayoutId();

    public abstract void initView(View view);

    public Toolbar setToolBarInfo(boolean hasBackBtn, String title) {
        if (hasTopView() && rootView != null) {
            Toolbar toolBar = (Toolbar) rootView.findViewById(R.id.toolbar);
            toolBar.setTitle(title);
            if (hasBackBtn)
                toolBar.setNavigationIcon(R.drawable.ic_action_back);
            return toolBar;
        }

        return null;
    }

//    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
//    @Override
//    public void onHiddenChanged(boolean hidden) {
//        Log.i("fragment111", " onHiddenChanged  " + hidden);
//        if (rootView != null) {
//            if (hidden) {
//                rootView.setFitsSystemWindows(false);
//            } else {
//                rootView.setFitsSystemWindows(true);
//            }
//            rootView.requestApplyInsets();
//        }
//        super.onHiddenChanged(hidden);
//    }

}

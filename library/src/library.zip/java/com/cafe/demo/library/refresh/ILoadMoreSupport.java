package com.cafe.demo.library.refresh;

/**
 * Created by cafe on 2017/5/7.
 */

public interface ILoadMoreSupport {

    void setOnLoadMoreListener(OnLoadMoreLinstener listener);

}

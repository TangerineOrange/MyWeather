package com.cafe.demo.library.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by WangKun on 2016/11/10.
 * Time : 2016/11/10,16:37.
 */

public abstract class BaseRecyclerAdapter<T> extends RecyclerView.Adapter<ViewHolder> {

    //item的类型 --头部
    private static final int ITEM_HEADER = 0;
    //item的类型 --普通
    private static final int ITEM_NORMAL = 1;

    private boolean isEnableClick = false;


    Context mContext;
    List<T> mDatas;
    private int mLayoutId;
    private LayoutInflater mInflater;

    //头部视图
    private View mHeaderView;

    //item 点击监听
    private OnItemClickListener onItemClickListener;
    private View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Log.i("click", "setOnItemClickListener " + onItemClickListener);
            Log.i("click", "setOnItemClickListener " + v);

            if (v.getTag() != null)
                onItemClickListener.onItemClick(v, (Integer) v.getTag());
            else
                onItemClickListener.onItemClick(v, -1);

        }
    };


    public View getmHeaderView() {
        return mHeaderView;
    }

    public void addDatas(ArrayList<T> datas) {
        datas.addAll(datas);
        notifyDataSetChanged();
    }

    public void setHeaderView(View mHeaderView) {
        this.mHeaderView = mHeaderView;
    }

    BaseRecyclerAdapter(Context context, int layoutId, List<T> datas) {
        this.mDatas = datas;
        this.mLayoutId = layoutId;
        this.mContext = context;
        mInflater = LayoutInflater.from(context);
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return ViewHolder.get(mContext, parent, mLayoutId);
    }


    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Log.i("bind", "bind " + position);

        holder.updatePosition(position);
        getView(holder, mDatas.get(position),position );


//        holder.setOnClickListener(R.id.id_text, clickListener);
//        holder.setItemOnClickListener(clickListener);
    }

    protected abstract void getView(ViewHolder holder, T t, int position);


    @Override
    public int getItemCount() {
        return mDatas.size();
    }


    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {

        this.onItemClickListener = onItemClickListener;
    }

    interface OnItemClickListener {
        void onItemClick(View view, int position);
    }


}

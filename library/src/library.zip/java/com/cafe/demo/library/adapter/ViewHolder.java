package com.cafe.demo.library.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by WangKun on 2016/11/13.
 * Time : 2016/11/13,15:05.
 */

public class ViewHolder extends RecyclerView.ViewHolder {

    private SparseArray<View> mViewArray;
    private View mItemView;
    private Context mContext;
    private int mViewType;

    /**
     * 初始化ViewHolder
     *
     * @param mContext 环境
     * @param itemView item的view
     * @param parent
     */
    public ViewHolder(Context mContext, View itemView, ViewGroup parent, int mViewType) {
        super(itemView);
        mViewArray = new SparseArray<>();
        this.mContext = mContext;
        this.mItemView = itemView;
        this.mViewType = mViewType;

    }

    /**
     * 初始化ViewHolder
     *
     * @param mContext 环境
     * @param itemView item的view
     * @param parent
     */
    public ViewHolder(Context mContext, View itemView, ViewGroup parent) {
        super(itemView);
        mViewArray = new SparseArray<>();
        this.mContext = mContext;
        this.mItemView = itemView;

    }

    public View getItemView() {
        return mItemView;
    }

    public void setItemOnClickListener(View.OnClickListener listener) {
        mItemView.setTag(getLayoutPosition());
        mItemView.setOnClickListener(listener);
    }


    /**
     * 创建viewholder
     *
     * @param context
     * @param parent
     * @param layoutId
     * @return
     */
    public static ViewHolder get(Context context, ViewGroup parent, int layoutId) {
        View itemView = LayoutInflater.from(context).inflate(layoutId, parent,
                false);

        return new ViewHolder(context, itemView, parent);
    }

    /**
     * 创建viewholder
     *
     * @param context
     * @param parent
     * @param layoutId
     * @return
     */
    public static ViewHolder get(Context context, ViewGroup parent, int layoutId, int mViewType) {
        View itemView = LayoutInflater.from(context).inflate(layoutId, parent,
                false);

        return new ViewHolder(context, itemView, parent, mViewType);
    }

    public int getviewType() {
        return mViewType;
    }


    /**
     * 通过viewId获取控件
     *
     * @param viewId
     * @return
     */
    @SuppressWarnings("unchecked")
    public <T extends View> T getView(int viewId) {
        View view = mViewArray.get(viewId);
        if (view == null) {
            view = mItemView.findViewById(viewId);
            mViewArray.put(viewId, view);
        }
        return (T) view;
    }

    public void updatePosition(int position) {

    }

    public ViewHolder setText(int viewId, String text) {
        TextView view = getView(viewId);
        if (view != null)
            view.setText(text);
        return this;
    }

    public ViewHolder appendText(int viewId, String text) {
        TextView view = getView(viewId);
        if (view != null)
            view.setText(view.getText().toString() + text);
        return this;
    }

    public ViewHolder setImageResource(int viewId, int resId) {
        ImageView view = getView(viewId);
        if (view != null)
            view.setImageResource(resId);
        return this;
    }

    public ViewHolder setOnClickListener(int viewId, View.OnClickListener listener) {
        View view = getView(viewId);
        if (view != null)
            view.setOnClickListener(listener);
        return this;
    }
}

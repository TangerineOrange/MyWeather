package com.cafe.demo.library.adapter;


import android.content.Context;
import android.view.ViewGroup;

import java.util.ArrayList;

/**
 * Created by WangKun on 2016/11/15.
 * Time : 2016/11/15,12:22.
 */

public abstract class MultiItemRecyclerAdapter<T> extends BaseRecyclerAdapter<T> {


    protected MultiItemTypeSupport<T> mMultiItemTypeSupport;

    public MultiItemRecyclerAdapter(Context context, ArrayList<T> datas, MultiItemTypeSupport<T> multiItemTypeSupport) {
        super(context, -1, datas);
        mMultiItemTypeSupport = multiItemTypeSupport;
    }


    @Override
    public int getItemViewType(int position) {
        return mMultiItemTypeSupport.getItemViewType(position, mDatas.get(position));
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        int layoutId = mMultiItemTypeSupport.getLayoutId(viewType);
        return ViewHolder.get(mContext, parent, layoutId, viewType);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        super.onBindViewHolder(holder, position);
        getView(holder, mDatas.get(position), position);
    }
}

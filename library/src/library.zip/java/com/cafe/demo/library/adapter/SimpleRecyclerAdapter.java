package com.cafe.demo.library.adapter;


import android.content.Context;

import java.util.List;

/**
 * Created by cafe on 2017/5/1.
 */

public abstract class SimpleRecyclerAdapter<T> extends BaseRecyclerAdapter<T> {

    public SimpleRecyclerAdapter(Context context, int layoutId, List<T> datas) {
        super(context, layoutId, datas);
    }
}
